package cse;

/**
 * on a CSE machine evaluation, handle Exception
 */
public class ExceptionHandlerOfCSE extends RuntimeException {
    public ExceptionHandlerOfCSE(String message) {
        super(message);
    }
}
